package com.example.projectuxlab;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
